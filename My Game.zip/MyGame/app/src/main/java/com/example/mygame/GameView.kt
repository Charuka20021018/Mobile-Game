package com.example.mygame

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

@SuppressLint("ViewConstructor")
class GameView(
    c: Context,
    private var gameTask: GameTask,
    private val sharedPreferences: SharedPreferences
) : View(c) {
        private var myPaint: Paint? = null
        private var speed = 1
        private var time = 1
        private var score = 0
        private var myBunnyPosition = 0
        private val otherBombs = ArrayList<HashMap<String, Any>>()
        private var highScore = 0
        private var viewWidth = 0
        private var viewHeight = 0


        init {
            myPaint = Paint()
            highScore = sharedPreferences.getInt(PREF_HIGH_SCORE_KEY,0)
        }

        @SuppressLint("DrawAllocation", "UseCompatLoadingForDrawables")
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            viewWidth = this.measuredWidth
            viewHeight = this.measuredHeight

            if (time % 700 < 10 + speed) {
                val map = HashMap<String, Any>()
                map["lane"] = (0..2).random()
                map["startTime"] = time
                otherBombs.add(map)
            }

            time += 10 + speed
            val bombWidth = 150
            val bombHeight = 150
            myPaint!!.style = Paint.Style.FILL
            val d = resources.getDrawable(R.drawable.bunny, null)

            d.setBounds(
                myBunnyPosition * viewWidth / 3,
                viewHeight - 2 - bombHeight,
                myBunnyPosition * viewWidth / 3 + bombWidth,
                viewHeight - 2
            )

            d.draw(canvas)
            myPaint!!.color = Color.GREEN

            // Retrieve high score from SharedPreferences
            val highScore = sharedPreferences.getInt(PREF_HIGH_SCORE_KEY, 0)

            for (i in otherBombs.indices) {
                try {
                    val bombX = otherBombs[i]["lane"] as Int * viewWidth / 3
                    val bombY = time - otherBombs[i]["startTime"] as Int
                    val d2 = resources.getDrawable(R.drawable.bomb, null)

                    d2.setBounds(
                        bombX,
                        bombY,
                        bombX + bombWidth,
                        bombY + bombHeight
                    )

                    d2.draw(canvas)
                    if (otherBombs[i]["lane"] as Int == myBunnyPosition) {
                        if (bombY > viewHeight - 2 - bombHeight && bombY < viewHeight - 2) {
                            gameTask.closeGame(score)
                        }
                    }

                    if (bombY > viewHeight + bombHeight) {
                        otherBombs.removeAt(i)
                        score++
                        speed = 1 + abs(score / 8)

                        // Update high score if necessary
                        if (score > highScore) {
                            sharedPreferences.edit().putInt(PREF_HIGH_SCORE_KEY, score).apply()
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            myPaint!!.color = Color.BLACK
            myPaint!!.textSize = 40f
            canvas.drawText("Score: $score", 50f, 80f, myPaint!!)
            canvas.drawText("Speed: $speed", 230f, 80f, myPaint!!)
            canvas.drawText("High Score: $highScore", 410f, 80f, myPaint!!)
            invalidate()
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(event: MotionEvent?): Boolean {
            when (event!!.action) {
                MotionEvent.ACTION_DOWN -> {
                    val x = event.x
                    if (x < viewWidth / 2) {
                        if (myBunnyPosition > 0) {
                            myBunnyPosition--
                        }
                    }
                    if (x > viewWidth / 2) {
                        if (myBunnyPosition < 2) {
                            myBunnyPosition++
                        }
                    }
                    invalidate()
                }
                MotionEvent.ACTION_UP -> {
                }
            }
            return true
        }

        companion object {
            private const val PREF_HIGH_SCORE_KEY = "high_score"
        }

}
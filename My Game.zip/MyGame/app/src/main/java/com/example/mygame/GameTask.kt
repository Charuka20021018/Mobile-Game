package com.example.mygame

interface GameTask {

    fun closeGame(mScore: Int)
}
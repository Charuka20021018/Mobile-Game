package com.example.mygame

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), GameTask {
    private lateinit var rootLayout: RelativeLayout
    private lateinit var startBtn: Button
    private lateinit var scoreTextView: TextView
    private lateinit var highScoreTextView: TextView
    private lateinit var gameView: GameView
    private lateinit var viewModel: GameViewModel
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var logo: ImageView
    private lateinit var text1: TextView
    private lateinit var text2: TextView


    @SuppressLint("MissingInflatedId", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        rootLayout = findViewById(R.id.rootLayout)
        startBtn = findViewById(R.id.button1)
        scoreTextView = findViewById(R.id.Score)
        highScoreTextView = findViewById(R.id.High_Score)
        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        logo = findViewById(R.id.rabbit)
        text1 = findViewById(R.id.text1)
        text2 = findViewById(R.id.text2)

        viewModel = GameViewModel()
        startBtn.visibility = View.VISIBLE

        startBtn.setOnClickListener {
            gameView = GameView(this, this, sharedPreferences)
            rootLayout.addView(gameView)
            text1.visibility = View.GONE
            text2.visibility = View.GONE
            startBtn.visibility = View.GONE
            scoreTextView.visibility = View.GONE
            logo.visibility = View.GONE
            highScoreTextView.visibility = View.GONE
        }

        // Load and display the high score
        val highScore = sharedPreferences.getInt(PREF_HIGH_SCORE_KEY, 0)
        highScoreTextView.text = "High Score: $highScore"
        
    }

    @SuppressLint("SetTextI18n")
    override fun closeGame(mScore: Int) {
        // Update and display the high score if the current score is higher
        val highScore = sharedPreferences.getInt(PREF_HIGH_SCORE_KEY, 0)
        if (mScore > highScore) {
            sharedPreferences.edit().putInt(PREF_HIGH_SCORE_KEY, mScore).apply()
            highScoreTextView.text = "High Score: $mScore"
        }

        scoreTextView.text = "Score: $mScore"
        rootLayout.removeView(gameView)
        startBtn.visibility = View.VISIBLE
        text1.visibility = View.VISIBLE
        text2.visibility = View.VISIBLE
        scoreTextView.visibility = View.VISIBLE
        highScoreTextView.visibility = View.VISIBLE
        logo.visibility = View.VISIBLE
    }

    companion object {
        private const val PREF_HIGH_SCORE_KEY = "high_score"
    }
}


package com.example.mygame

import androidx.lifecycle.ViewModel

class GameViewModel : ViewModel() {
    var score = 0
    var speed = 1
    var myShipPosition = 0
}